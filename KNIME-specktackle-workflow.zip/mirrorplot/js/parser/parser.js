/**
 * parser stub.
 *
 * Parsers for input data should extend this stub.
 * 
 * @author Stephan Beisken <beisken@ebi.ac.uk>
 * @constructor
 */
st.parser = {};