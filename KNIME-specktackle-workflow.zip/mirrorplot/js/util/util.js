/**
 * util stub.
 * 
 * @author Stephan Beisken <beisken@ebi.ac.uk>
 * @constructor
 */
st.util = {};